#!/bin/sh

### Author: Michael Grubb <mtg@dailyvoid.com>
### File:   /Users/mgrubb/.vim/templates/sh/test.sh
### Description: test.sh -- <+ SHORT_DESC +>
### Copyright: (C) 2010, Michael Grubb <mtg@dailyvoid.com>
### Modeline: vim:tw=79:sw=4:ts=4:ai:
### Description: <+ DESCRIPTION +>

PROG=`basename $0`

for i in `cat /etc/passwd | cut -d: -f1`
do
	echo $i
done

if test -d "${HOME}/."
then
	echo "found home"
fi

while [ -d "${HOME}/." ]
do
	echo "found home"
done

while test -d "${HOME}/."
do
	echo "Found home"
done

case "$i" in
	-t)
		/bin/true;;
esac

echo this is an error message >&2
echo "this is an error message" >&2
echo "another error" >&2


