/*****************************************************************************
 *****************************************************************************
 **** Author: <! g:tpv['author'] !> <<! g:tpv['email'] !>>
 **** File:   <! expand("%:p") !>
 **** Description: <! expand("%:t") !> -- <+ SHORT_DESC +>
 **** Copyright: (C) <! strftime('%Y') !>, <! g:tpv["author"] !>. All rights reserved.
 **** Modeline: vim:<! g:tpv["modeline"] !>:
 **** Description: <+ DESCRIPTION +>
 *****************************************************************************
 ****************************************************************************/

#include <unistd.h>
#include <stdlib.h>

${cursor}

