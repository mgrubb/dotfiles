#!<! g:tpv["shell"] !>

### Author: <! g:tpv["author"] !> <<! g:tpv["email"] !>>
### File:   <! expand("%:p") !>
### Description: <! expand("%:t") !> -- <+ SHORT_DESC +>
### Copyright: (C) <! strftime('%Y') !>, <! g:tpv["author"] !> <<! g:tpv["email"] !>>
### Modeline: vim:<! g:tpv["modeline"] !>:
### Description: <+ DESCRIPTION +>

PROG=`basename $0`

${cursor}

